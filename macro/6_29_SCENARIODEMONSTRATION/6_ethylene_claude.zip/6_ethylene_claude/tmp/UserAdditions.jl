module UserAdditions
using MacroEnergy

if isfile("/Users/abbie/MacroEnergyExamples.jl/macro/new_11w_test_reduced/tmp/usersubcommodities.jl")
    include("/Users/abbie/MacroEnergyExamples.jl/macro/new_11w_test_reduced/tmp/usersubcommodities.jl")
end

if isfile("/Users/abbie/MacroEnergyExamples.jl/macro/new_11w_test_reduced/tmp/userassets.jl")
    include("/Users/abbie/MacroEnergyExamples.jl/macro/new_11w_test_reduced/tmp/userassets.jl")
end

end
